3D_nanshan — Apartment V1

DELIVERABLES
- House_Mobile.glb : mobile glTF/GLB model
- index.html : touch-first 360° web viewer
- blender_v1_generator.py : editable Blender parametric master generator
- build_house_v2.py : reproducible GLB builder

LOCKED DESIGN BASIS
- Structural floor-to-floor / slab height reference: 2.95 m
- Existing finished ceiling retained; partial bulkheads reconstructed rather than a universal 2.65 m flat ceiling
- Gross area reference: 123 m²; internal area reference: 96 m²
- Three-bedroom V1 follows supplied concept plan; partitions remain editable
- Existing living/dining/corridor tile retained
- Bedroom finish changed to timber flooring
- Existing kitchen cabinetry retained
- Both bathroom hard finishes retained
- Existing enclosed balcony windows retained
- Living–balcony internal glazed divider removed; former balcony fully integrated into living room
- Former balcony: stacked washer/dryer on one side, parametric housekeeping cabinet on the other
- Beds: master 1.8×2.0 m; secondary 1.5×2.0 m; north bedroom 1.2×2.0 m
- Living room uses TV; TV object is parametric
- Sofa alternatives retained: 2.5 m straight option + modular curved option

MODEL STATUS
This is a spatial/design V1 reconstructed from the supplied drawings and site photos. It is suitable for layout review and mobile visualization, not for fabrication or construction setting-out. Site measurements should replace inferred dimensions before construction documentation.

PHONE VIEWER
Deploy index.html and House_Mobile.glb in the same web directory. The viewer supports one-finger orbit, pinch zoom and preset room views.
