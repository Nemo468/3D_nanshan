# Apartment V1 Blender parametric generator
# Run in Blender > Scripting. Units: metres. Geometry matches House_Mobile.glb zoning.
import bpy, math
P={'structural_h':2.95,'wall_h':2.65,'wall_t':.12,'internal_area':96.0,'gross_area':123.0,'balcony_w':4.55,'balcony_d':1.30,'secondary':(2.80,3.20),'master':(3.30,4.40),'north_bed':(2.60,2.50),'sofa_straight':2.50}
for o in list(bpy.data.objects): bpy.data.objects.remove(o,do_unlink=True)
for n in ['01_ARCH','02_EXISTING_FITOUT','03_RENOVATION','04_CUSTOM_FURNITURE']:
 c=bpy.data.collections.get(n) or bpy.data.collections.new(n)
 if c.name not in bpy.context.scene.collection.children: bpy.context.scene.collection.children.link(c)
def box(n,s,l,col='01_ARCH'):
 bpy.ops.mesh.primitive_cube_add(location=l); o=bpy.context.object; o.name=n; o.dimensions=s; bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 for c in list(o.users_collection): c.objects.unlink(o)
 bpy.data.collections[col].objects.link(o); return o
def wall(n,a,b,h=None,t=None,col='01_ARCH'):
 h=h or P['wall_h']; t=t or P['wall_t']; x1,y1=a; x2,y2=b; dx=x2-x1;dy=y2-y1;L=(dx*dx+dy*dy)**.5
 o=box(n,(L,t,h),((x1+x2)/2,(y1+y2)/2,h/2),col);o.rotation_euler[2]=math.atan2(dy,dx);return o
def floor(n,x,y,w,d,col='01_ARCH'): return box(n,(w,d,.05),(x+w/2,y+d/2,.025),col)
def bed(n,x,y,w,l): box(n+'_base',(w+.08,l+.08,.28),(x+w/2,y+l/2,.16),'04_CUSTOM_FURNITURE');box(n+'_mattress',(w,l,.22),(x+w/2,y+l/2,.40),'04_CUSTOM_FURNITURE')
# Floors
for a in [('LivingDining',0,1.30,4.55,7.10),('FormerBalcony',0,0,4.55,1.30),('Secondary',4.55,1.30,2.80,3.20),('Master',7.35,1.30,3.30,4.40),('NorthBedroom',6.05,5.90,2.60,2.50),('Kitchen',0,5.80,2.05,2.60),('PublicBath',4.45,5.90,1.60,2.50),('MasterBath',8.65,5.90,1.60,2.50)]: floor(*a)
# Exterior / partitions. Balcony-living divider intentionally removed.
segments=[('West',(0,1.3),(0,8.4)),('North',(0,8.4),(10.25,8.4)),('SouthBeds',(4.55,1.3),(10.65,1.3)),('LivingSecondary',(4.55,1.3),(4.55,4.5)),('SecondaryEast',(7.35,1.3),(7.35,4.5)),('KitchenEast',(2.05,5.8),(2.05,8.4)),('PublicWest',(4.45,5.9),(4.45,8.4)),('PublicEast',(6.05,5.9),(6.05,8.4)),('NorthBedEast',(8.65,5.9),(8.65,8.4)),('MasterBathEast',(10.25,5.9),(10.25,8.4))]
for n,a,b in segments: wall(n,a,b)
# Door-gapped walls
for n,a,b in [('SecondaryNorthL',(4.55,4.5),(5.2,4.5)),('SecondaryNorthR',(6.1,4.5),(7.35,4.5)),('NorthBedSouthL',(6.05,5.9),(6.55,5.9)),('NorthBedSouthR',(7.45,5.9),(8.65,5.9)),('MasterNorthL',(7.35,5.7),(8.05,5.7)),('MasterNorthR',(8.95,5.7),(10.65,5.7))]: wall(n,a,b)
# Existing + custom furniture placeholders
box('KitchenExistingRun',(.62,2.15,.88),(.46,7.125,.44),'02_EXISTING_FITOUT')
bed('SecondaryBed',4.72,1.72,1.50,2.00);bed('MasterBed',7.70,1.72,1.80,2.00);bed('NorthBed',6.22,6.12,1.20,2.00)
box('SofaStraightOPTION',(2.50,.92,.70),(2.95,3.35,.37),'04_CUSTOM_FURNITURE');box('TVParametric',(.055,1.65,.95),(.43,4.05,1.35),'04_CUSTOM_FURNITURE')
box('LaundryStack',(.78,.70,2.05),(.57,.53,1.025),'04_CUSTOM_FURNITURE');box('HousekeepingCabinet',(.62,.62,2.35),(4.09,.49,1.175),'04_CUSTOM_FURNITURE')
# Review camera
bpy.ops.object.camera_add(location=(14,-14,13));cam=bpy.context.object;cam.name='ReviewCamera';bpy.context.scene.camera=cam
print('V1 generated. Spatial model only; verify on-site dimensions before construction.')
