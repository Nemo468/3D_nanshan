import trimesh, os, math
OUT='/mnt/data/house_v1'; os.makedirs(OUT,exist_ok=True)
scene=trimesh.Scene(); H=2.95; WALL_H=2.65; WT=.12

def material(rgb,a=1,rough=.72,metal=0):
    return trimesh.visual.material.PBRMaterial(baseColorFactor=[*rgb,a],roughnessFactor=rough,metallicFactor=metal)
W=material([.93,.92,.89]); TILE=material([.67,.66,.63]); WOOD=material([.58,.42,.27]); GLASS=material([.30,.52,.62],.28,.25); WHITE=material([.92,.91,.87]); FAB=material([.58,.52,.47]); BED=material([.80,.76,.69]); DARK=material([.12,.13,.14],1,.4,.1); METAL=material([.34,.35,.36],1,.35,.45); BLUE=material([.38,.48,.56]);

def add_box(name,size,loc,mat):
    m=trimesh.creation.box(extents=size); m.apply_translation(loc); m.visual.material=mat; scene.add_geometry(m,node_name=name,geom_name=name)

def wall(name,x1,y1,x2,y2,h=WALL_H,t=WT,z0=0,mat=W):
    dx,dy=x2-x1,y2-y1; L=(dx*dx+dy*dy)**.5; ang=math.atan2(dy,dx)
    m=trimesh.creation.box(extents=[L,t,h]); T=trimesh.transformations.rotation_matrix(ang,[0,0,1]); T[:3,3]=[(x1+x2)/2,(y1+y2)/2,z0+h/2]; m.apply_transform(T); m.visual.material=mat; scene.add_geometry(m,node_name=name,geom_name=name)

def floor(name,x,y,w,d,mat): add_box(name,[w,d,.045],[x+w/2,y+d/2,.0225],mat)

def bed(name,x,y,w,l,rot=0):
    # rotation currently only 0/90
    if rot==90: w,l=l,w
    add_box(name+'_base',[w+0.08,l+0.08,.28],[x+w/2,y+l/2,.16],WHITE)
    add_box(name+'_mattress',[w,l,.22],[x+w/2,y+l/2,.40],BED)

def cabinet(name,x,y,w,d,h,mat=WHITE): add_box(name,[w,d,h],[x+w/2,y+d/2,h/2],mat)

# Coordinate system follows supplied mirrored plan: balcony south, service rooms north.
# Dimension anchors from plan: balcony 4.55x1.30; living depth 7.10; secondary 2.80x3.20; master 3.30x4.40;
# kitchen 2.05x~2.6; public bath 1.60x~2.5; north bedroom/study 2.60x~2.5; master bath 1.60x~2.5.
# Main lower width = living 4.55 + secondary 2.80 + master 3.30 = 10.65m (zoned, not construction survey).

# Floors
floor('Living_Dining_existing_tile',0,1.30,4.55,7.10,TILE)
floor('Former_Balcony_existing_tile',0,0,4.55,1.30,TILE)
floor('Secondary_Bedroom_new_wood',4.55,1.30,2.80,3.20,WOOD)
floor('Master_Bedroom_new_wood',7.35,1.30,3.30,4.40,WOOD)
floor('North_Bedroom_new_wood',6.05,5.90,2.60,2.50,WOOD)
floor('Kitchen_existing_tile',0,5.80,2.05,2.60,TILE)
floor('Public_Bath_existing_tile',4.45,5.90,1.60,2.50,TILE)
floor('Master_Bath_existing_tile',8.65,5.90,1.60,2.50,TILE)
floor('Hall_existing_tile',4.55,4.50,1.50,1.40,TILE)

# Exterior / major walls; balcony-living divider intentionally absent (fully opened)
wall('West_main',0,1.30,0,8.40); wall('North_main',0,8.40,10.25,8.40); wall('East_master',10.65,1.30,10.65,5.70); wall('East_service',10.25,5.90,10.25,8.40)
wall('South_bedrooms',4.55,1.30,10.65,1.30)
# Balcony exterior: low sill + glazing, existing enclosed window retained
wall('Balcony_west',0,0,0,1.30); wall('Balcony_east',4.55,0,4.55,1.30)
wall('Balcony_sill',0,0,4.55,0,.82,.12,0,W); wall('Balcony_glass',0.05,-.015,4.50,-.015,1.70,.045,.82,GLASS)
# bedroom outer window wall/sills
wall('Secondary_south_sill',4.55,1.30,7.35,1.30,.52,.16,0,W); wall('Secondary_window',4.70,1.27,7.20,1.27,1.62,.045,.52,GLASS)
wall('Master_south_sill',7.35,1.30,10.65,1.30,.52,.16,0,W); wall('Master_window',7.55,1.27,10.45,1.27,1.62,.045,.52,GLASS)
# Interior partitions
wall('Living_secondary',4.55,1.30,4.55,4.50)
wall('Secondary_east',7.35,1.30,7.35,4.50)
wall('Secondary_north_left',4.55,4.50,5.20,4.50); wall('Secondary_north_right',6.10,4.50,7.35,4.50) # door gap
wall('Master_west_lower',7.35,1.30,7.35,4.85); wall('Master_north_left',7.35,5.70,8.05,5.70); wall('Master_north_right',8.95,5.70,10.65,5.70)
# service strip partitions and openings
wall('Kitchen_east',2.05,5.80,2.05,8.40)
wall('Kitchen_south_left',0,5.80,.55,5.80); wall('Kitchen_south_right',1.45,5.80,2.05,5.80)
wall('PublicBath_west',4.45,5.90,4.45,8.40); wall('PublicBath_east',6.05,5.90,6.05,8.40)
wall('NorthBed_east',8.65,5.90,8.65,8.40)
wall('MasterBath_east',10.25,5.90,10.25,8.40)
# north bedroom south wall with door gap; editable layer concept represented by named nodes
wall('NorthBed_south_L',6.05,5.90,6.55,5.90); wall('NorthBed_south_R',7.45,5.90,8.65,5.90)
# master bath south with door gap
wall('MasterBath_south_L',8.65,5.90,9.05,5.90); wall('MasterBath_south_R',9.85,5.90,10.25,5.90)
# Public bath south
wall('PublicBath_south_L',4.45,5.90,4.75,5.90); wall('PublicBath_south_R',5.55,5.90,6.05,5.90)

# Existing fitout - simplified but distinct
cabinet('Kitchen_base_west',.15,6.05,.62,2.15,.88,WHITE); cabinet('Kitchen_base_north',.77,7.72,1.12,.62,.88,WHITE)
add_box('Kitchen_counter_west',[.64,2.15,.045],[.46,7.125,.91],DARK); add_box('Kitchen_counter_north',[1.12,.64,.045],[1.33,8.03,.91],DARK)
# bathroom vanity/shower placeholders
for prefix,x in [('Public',4.55),('MasterBath',8.75)]:
    cabinet(prefix+'_vanity',x,7.58,.72,.48,.82,WHITE); add_box(prefix+'_shower',[.78,.78,1.95],[x+.95,6.42,.98],GLASS)

# Custom furniture V1
bed('SecondaryBed_1500x2000',4.72,1.72,1.50,2.00)
bed('MasterBed_1800x2000',7.70,1.72,1.80,2.00)
bed('NorthBed_1200x2000',6.22,6.12,1.20,2.00)
cabinet('MasterWardrobe_parametric',10.00,2.05,.58,2.55,2.35,WHITE)
cabinet('SecondaryWardrobe_parametric',6.68,1.55,.55,1.65,2.35,WHITE)
cabinet('NorthWardrobe_parametric',8.02,6.05,.52,1.55,2.35,WHITE)
# living straight sofa option
add_box('Sofa_Straight_OPTION_2500',[2.50,.92,.70],[2.95,3.35,.37],FAB)
# curved option approximated with three modules, separate nodes
add_box('Sofa_Curved_OPTION_center',[1.45,.88,.68],[2.95,3.35,.36],BLUE); add_box('Sofa_Curved_OPTION_left',[.72,.82,.68],[1.93,3.25,.36],BLUE); add_box('Sofa_Curved_OPTION_right',[.72,.82,.68],[3.97,3.25,.36],BLUE)
# TV and modular unit
cabinet('TV_modular_low_unit',.20,3.00,.38,2.10,.62,WHITE); add_box('TV_parametric',[.055,1.65,.95],[.43,4.05,1.35],DARK)
# dining / island reference
add_box('DiningTable_V1',[1.45,.82,.74],[2.65,6.68,.39],FAB)
# balcony integrated service sides: stacked washer/dryer + housekeeping
cabinet('Laundry_stack_housing',.18,.18,.78,.70,2.05,WHITE)
for i in range(2):
    cyl=trimesh.creation.cylinder(radius=.25,height=.035,sections=32); cyl.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[1,0,0])); cyl.apply_translation([.57,.165,.55+i*.78]); cyl.visual.material=DARK; scene.add_geometry(cyl,node_name=f'Laundry_door_{i}',geom_name=f'Laundry_door_{i}')
cabinet('HousekeepingCabinet_parametric',3.78,.18,.62,.62,2.35,WHITE)

# Ceiling hints: existing partial perimeter/AC bulkheads, not a flat whole-home ceiling
add_box('Living_perimeter_bulkhead',[4.55,.42,.20],[2.275,8.16,2.55],WHITE)
add_box('Living_AC_slot',[2.10,.05,.08],[2.50,7.94,2.48],DARK)

# scene camera-ish metadata and export
scene.metadata={'title':'Apartment V1 mobile model','structural_height_m':2.95,'internal_area_m2':96,'gross_area_m2':123,'note':'Spatial V1 based on supplied dimension drawings/photos; not construction survey.'}
path=os.path.join(OUT,'House_Mobile.glb'); scene.export(path); print(path,os.path.getsize(path))
